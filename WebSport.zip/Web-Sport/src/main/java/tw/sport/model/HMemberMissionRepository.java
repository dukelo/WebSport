package tw.sport.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HMemberMissionRepository extends JpaRepository<HMemberMission, Integer> {

}
